<!-- without the index.php file we prevent access to the directory -->
<?php // silence is golden 