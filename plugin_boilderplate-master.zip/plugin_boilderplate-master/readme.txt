=== Blick Plugin   ===
Plugin Name: BlickPlugin
Description: Welcome to the Blick Plugin.
Plugin URI:  foo@foo.com
Author:      Blick Creative
Version:     1.0
License:     GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.txt

Here is a short description of the plugin. This should be no more than 150 characters. No markup here.